
#include <stdint.h>
#include <stdbool.h>
#include <stdio.h>
#include <string.h>
#include <assert.h>
typedef uint8_t bd_addr_t[6];
#define ERROR_CODE_SUCCESS 0
#define L2CAP_DATA_PACKET 1
#define HCI_EVENT_PACKET 2
#define L2CAP_EVENT_CAN_SEND_NOW 3
#define L2CAP_EVENT_CHANNEL_OPENED 4
#define L2CAP_EVENT_CHANNEL_CLOSED 5
static struct { uint8_t game_level; } test_settings;
static int test_send_rc;
static unsigned media_events;
static void *settings(void); /* macro below gives the concrete type */
#define settings() (&test_settings)
static uint32_t btstack_run_loop_get_time_ms(void){return 100;}
static int l2cap_request_can_send_now_event(uint16_t cid){return 0;}
static int l2cap_send(uint16_t cid,uint8_t *p,uint16_t n){return test_send_rc;}
static uint8_t hci_event_packet_get_type(uint8_t *p){return p[0];}
static uint8_t l2cap_event_channel_opened_get_status(uint8_t *p){return p[1];}
static uint16_t l2cap_event_channel_opened_get_local_cid(uint8_t *p){return p[2];}
static uint16_t l2cap_event_channel_closed_get_local_cid(uint8_t *p){return p[2];}
static const char *bd_addr_to_str(uint8_t *p){return "peer";}
static int l2cap_create_channel(void(*fn)(uint8_t,uint16_t,uint8_t*,uint16_t),uint8_t *addr,int psm,int mtu,uint16_t *cid){*cid=0x42;return 0;}
static int l2cap_disconnect(uint16_t cid){return 0;}
static void usb_hid_consumer(int usage){media_events++;}
static void a2dp_source_on_aap_wake(void){}
/*
 * btstack_aap.c — AirPods AACP client over L2CAP PSM 0x1001 (Full only).
 *
 * Reconstructed from the shipped Full firmware's AAP module and the packet
 * layouts documented by the LibrePods reverse-engineering work:
 *
 *   handshake        00 00 04 00 01 00 02 00 00 00 00 00 00 00 00 00
 *   set features     04 00 04 00 4D 00 D7 00 00 00 00 00 00 00
 *   notifications    04 00 04 00 0F 00 FF FF FF FF
 *   control command  04 00 04 00 09 00 <id> <v> 00 00 00
 *     0x0B jitter buffer (ms)      0x0D noise mode
 *     0x26 personalised volume     0x28 conversation awareness
 *     0x2E adaptive audio level
 *   notifications    0x04 battery, 0x06 ear detection, 0x09 control state,
 *                    0x19 stem press
 *
 * There is no licence gate in this build: every AACP feature is enabled.
 */


#define AAP_PSM 0x1001
#define AAP_MTU 672

#define OP_ACK          0x01
#define OP_BATTERY      0x04
#define OP_EAR          0x06
#define OP_CONTROL      0x09
#define OP_FEATURES_ACK 0x2B
#define OP_METADATA     0x1D
#define OP_STEM         0x19
#define OP_CA_EVENT     0x4B

#define CTL_JITTER      0x0B
#define CTL_NOISE       0x0D
#define CTL_ONE_BUD_ANC 0x1B
#define CTL_PVOL        0x26
#define CTL_CA          0x28
#define CTL_AA          0x2E

static uint16_t s_cid;
static bool     s_opening;
static bool     s_open;
static bool     s_protocol_seen;

/* TX ring: provisioning is a seven-frame burst and the controller has only
 * six ACL buffers.  Queue frames and drain them on CAN_SEND_NOW instead of
 * firing seven l2cap_send() calls into a full pipe. */
#define AAP_TX_SLOTS 8
#define AAP_TX_MAX   32
static uint8_t  s_tx[AAP_TX_SLOTS][AAP_TX_MAX];
static uint8_t  s_tx_len[AAP_TX_SLOTS];
static uint8_t  s_tx_head, s_tx_tail;
static bool     s_tx_waiting;

static uint8_t  s_noise_mode;
static bool     s_ear_pause;
static bool     s_game;
static int      s_pvol = -1;
static int      s_ca = -1;
static int      s_aa = -1;
static uint8_t  s_jitter = 150;
static int      s_ear_last = -1;      /* 0 both in, 1 some out, 2 in case */
static uint32_t s_last_lock_ms;
static uint32_t s_last_render_ms;
static bool     s_renderer_live;

static uint8_t  s_battery[3] = { 0xFF, 0xFF, 0xFF };
static bd_addr_t s_addr;

volatile bool aap_rx_log = false;

static uint32_t now_ms(void) { return btstack_run_loop_get_time_ms(); }

static void aap_tx_kick(void)
{
    if (s_tx_waiting || !s_open || s_cid == 0) return;
    if (s_tx_tail == s_tx_head) return;
    s_tx_waiting = true;
    if (l2cap_request_can_send_now_event(s_cid) != ERROR_CODE_SUCCESS)
        s_tx_waiting = false;
}

static void aap_send(const uint8_t *p, uint16_t n)
{
    if (!s_open || s_cid == 0) {
        printf("AAP: no channel \n");
        return;
    }
    if (n > AAP_TX_MAX) {
        printf("AAP: tx queue full / pkt too big (%u)\n", (unsigned)n);
        return;
    }
    uint8_t next = (uint8_t)((s_tx_head + 1) % AAP_TX_SLOTS);
    if (next == s_tx_tail) {
        printf("AAP: tx queue full / pkt too big (%u)\n", (unsigned)n);
        return;
    }
    memcpy(s_tx[s_tx_head], p, n);
    s_tx_len[s_tx_head] = (uint8_t)n;
    s_tx_head = next;
    s_last_lock_ms = now_ms();
    aap_tx_kick();
}

/* Safety: only control IDs with factory-side evidence may be transmitted.
 * Unknown IDs are refused rather than guessed.  The two console-only probes
 * (0x4C and 0x09/0x03) are disabled until their factory behaviour is audited. */
#define AAP_ALLOW_DEBUG_PROBES 0

static bool aap_ctl_id_allowed(uint8_t id)
{
    switch (id) {
        case 0x0B:   /* jitter buffer (factory log string)            */
        case 0x0D:   /* noise mode (factory parser + page values)     */
        case 0x26:   /* personalised volume                           */
        case 0x28:   /* conversation awareness                        */
        case 0x2E:   /* adaptive audio strength                       */
            return true;
        default:
            return false;
    }
}

static void aap_send_ctl(uint8_t id, uint8_t value)
{
    if (!aap_ctl_id_allowed(id)) {
        printf("AAP: refusing unverified control 0x%02x (no factory evidence)\n", id);
        return;
    }
    uint8_t p[11] = { 0x04, 0x00, 0x04, 0x00, 0x09, 0x00, id, value, 0, 0, 0 };
    printf("[aap>] ctl 0x%02x = 0x%02x\n", id, value);
    aap_send(p, sizeof(p));
}

static void aap_send_provisioning(void)
{
    /* Exact sequence recovered from published-prod.uf2 at 0x1014db14..60:
     * handshake, set-features, request-notifications, head-tracking stop,
     * then the three macOS provisioning control commands.  The factory sends
     * all seven immediately on channel open; it does not wait for the ACKs. */
    static const uint8_t f1[16] = {
        0x00,0x00,0x04,0x00,0x01,0x00,0x02,0x00,
        0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00
    };
    static const uint8_t f2[14] = {
        0x04,0x00,0x04,0x00,0x4D,0x00,0xD7,0x00,
        0x00,0x00,0x00,0x00,0x00,0x00
    };
    static const uint8_t f3[10] = {
        0x04,0x00,0x04,0x00,0x0F,0x00,0xFF,0xFF,0xFF,0xFF
    };
    static const uint8_t f4[29] = {
        0x04,0x00,0x04,0x00,0x17,0x00,0x00,0x00,0x10,0x00,
        0x11,0x00,0x08,0x7E,0x10,0x02,0x42,0x0B,0x08,0x4E,
        0x10,0x02,0x1A,0x05,0x01,0x00,0x00,0x00,0x00
    };
    static const uint8_t f5[11] = { 0x04,0x00,0x04,0x00,0x09,0x00,0x13,0x01,0x00,0x00,0x00 };
    static const uint8_t f6[11] = { 0x04,0x00,0x04,0x00,0x09,0x00,0x12,0x02,0x00,0x00,0x00 };
    static const uint8_t f7[11] = { 0x04,0x00,0x04,0x00,0x09,0x00,0x39,0x07,0x00,0x00,0x00 };

    aap_send(f1, sizeof(f1));
    aap_send(f2, sizeof(f2));
    aap_send(f3, sizeof(f3));
    aap_send(f4, sizeof(f4));
    aap_send(f5, sizeof(f5));
    aap_send(f6, sizeof(f6));
    aap_send(f7, sizeof(f7));
    printf("AAP: macOS provisioning replay (7 frames, factory 0x1014db14..60)\n");
}

/* --------------------------------------------------------------- parsing */

static void parse_battery(const uint8_t *p, uint16_t n)
{
    if (n < 7) return;
    uint8_t count = p[6];
    int off = 7;
    for (uint8_t i = 0; i < count && off + 4 < n; i++, off += 5) {
        uint8_t comp  = p[off];
        uint8_t level = p[off + 2];
        uint8_t status = p[off + 3];
        uint8_t v = (uint8_t)(level & 0x7F);
        if (status == 0x01) v |= 0x80;        /* charging */
        if (status == 0x04) v = 0xFF;         /* disconnected */
        switch (comp) {
            case 0x04: s_battery[0] = v; break;   /* left  */
            case 0x02: s_battery[1] = v; break;   /* right */
            case 0x08: s_battery[2] = v; break;   /* case  */
            default: break;
        }
        const char *name = comp == 0x04 ? "left" : comp == 0x02 ? "right" :
                           comp == 0x08 ? "case" : "?";
        printf(" %s=%u%%%s\n", name, level & 0x7F,
               status == 0x01 ? "+" : "");
    }
}

static void parse_ear(const uint8_t *p, uint16_t n)
{
    if (n < 8) return;
    uint8_t a = p[6], b = p[7];
    int state;
    if (a == 0x02 || b == 0x02) state = 2;
    else if (a == 0x00 && b == 0x00) state = 0;
    else state = 1;

    printf("AAP ear detection: %s\n", state == 0 ? "worn" :
           state == 1 ? "removed" : "in case");

    if (state != s_ear_last) {
        if (s_ear_pause) {
            if (state == 0) {
                usb_hid_consumer(0x00CD);          /* resume */
                a2dp_source_on_aap_wake();
            } else if (s_ear_last == 0) {
                usb_hid_consumer(0x00CD);          /* pause */
            }
        } else if (state == 0) {
            a2dp_source_on_aap_wake();
        }
        s_ear_last = state;
    }
}

static void parse_stem(const uint8_t *p, uint16_t n)
{
    if (n < 8) return;
    uint8_t press = p[6], bud = p[7];
    const char *side = bud == 0x01 ? "left" : bud == 0x02 ? "right" : "?";
    switch (press) {
        case 0x05:
            printf("AAP stem: single (%s) -> play/pause\n", side);
            usb_hid_consumer(0x00CD);
            break;
        case 0x06:
            printf("AAP stem: double (%s) -> next\n", side);
            usb_hid_consumer(0x00B5);
            break;
        case 0x07:
            printf("AAP stem: triple (%s) -> previous\n", side);
            usb_hid_consumer(0x00B6);
            break;
        default:
            break;
    }
}

static void parse_control(const uint8_t *p, uint16_t n)
{
    if (n < 8) return;
    uint8_t id = p[6];
    uint8_t v  = p[7];
    switch (id) {
        case CTL_NOISE:
            s_noise_mode = v;
            printf("AAP noise mode -> %u (1=Off 2=ANC 3=Transp 4=Adaptive)\n", v);
            break;
        case CTL_PVOL:
            s_pvol = (v == 1);
            printf("AAP personalized volume -> %s\n", v == 1 ? "ON" : "off");
            break;
        case CTL_CA:
            s_ca = (v == 1);
            printf("AAP conversation awareness -> %s\n", v == 1 ? "ON" : "off");
            break;
        case CTL_AA:
            s_aa = v;
            printf("AAP adaptive audio strength -> %u\n", v);
            break;
        default:
            if (aap_rx_log) printf("AAP: ctrl 0x%02x ignored \n", id);
            break;
    }
}

static void aap_handle_packet(const uint8_t *p, uint16_t n)
{
    if (n < 6) return;
    uint16_t op = (uint16_t)(p[4] | (p[5] << 8));

    s_protocol_seen = true;

    if (aap_rx_log) {
        uint32_t t = now_ms();
        printf("[aap<] t %lu len %u %s%s\n", (unsigned long)t, n,
               op == OP_BATTERY ? "battery" :
               op == OP_EAR ? "ear" :
               op == OP_CONTROL ? "ctrl" :
               op == OP_STEM ? "stem" :
               op == OP_CA_EVENT ? "ca" : "", "");
    }

    if (p[0] == 0x01 && p[2] == 0x04 && p[3] == 0x00 && op == OP_ACK) {
        printf("AAP: handshake ACK\n");
        return;
    }
    if (op == OP_FEATURES_ACK) {
        return;
    }

    switch (op) {
        case OP_BATTERY:  printf("AAP battery:\n"); parse_battery(p, n); break;
        case OP_EAR:      parse_ear(p, n); break;
        case OP_CONTROL:  parse_control(p, n); break;
        case OP_STEM:     parse_stem(p, n); break;
        case OP_METADATA: break;
        case OP_CA_EVENT: break;
        default:
            if (aap_rx_log) printf("AAP: ctrl 0x%02x ignored \n", op & 0xFF);
            break;
    }
}

/* ------------------------------------------------------------ L2CAP glue */

static void aap_packet_handler(uint8_t packet_type, uint16_t channel,
                               uint8_t *packet, uint16_t size)
{
    (void)channel;
    switch (packet_type) {
        case L2CAP_DATA_PACKET:
            aap_handle_packet(packet, size);
            break;
        case HCI_EVENT_PACKET: {
            uint8_t ev = hci_event_packet_get_type(packet);
            if (ev == L2CAP_EVENT_CAN_SEND_NOW) {
                s_tx_waiting = false;
                if (s_tx_tail != s_tx_head && s_cid) {
                    uint8_t slot = s_tx_tail;
                    uint8_t len  = s_tx_len[slot];
                    int rc = l2cap_send(s_cid, s_tx[slot], len);
                    s_tx_tail = (uint8_t)((slot + 1) % AAP_TX_SLOTS);
                    if (rc != 0)
                        printf("AAP: tx send failed 0x%02x\n", rc);
                    aap_tx_kick();
                }
                break;
            }
            if (ev == L2CAP_EVENT_CHANNEL_OPENED) {
                uint8_t status = l2cap_event_channel_opened_get_status(packet);
                if (status != 0 && status != ERROR_CODE_SUCCESS) {
                    printf("AAP: L2CAP open FAILED, status 0x%02x (non-Apple sink?)\n", status);
                    s_opening = false;
                    s_open = false;
                    s_cid = 0;
                    break;
                }
                s_cid = l2cap_event_channel_opened_get_local_cid(packet);
                s_opening = false;
                s_open = true;
                s_protocol_seen = false;
                s_tx_head = s_tx_tail = 0;
                s_tx_waiting = false;
                s_battery[0] = s_battery[1] = s_battery[2] = 0xFF;
                s_noise_mode = 0;
                s_pvol = s_ca = s_aa = -1;
                s_ear_last = -1;
                printf("AAP: L2CAP open (PSM 0x%04x) cid 0x%04x -> init sequence\n",
                       AAP_PSM, s_cid);
                aap_send_provisioning();
            } else if (ev == L2CAP_EVENT_CHANNEL_CLOSED) {
                uint16_t cid = l2cap_event_channel_closed_get_local_cid(packet);
                if (cid == s_cid || s_cid == 0)
                    printf("AAP: L2CAP channel closed%s\n",
                           s_open ? "" : " (stale cid)");
                s_open = false;
                s_opening = false;
                s_cid = 0;
                s_protocol_seen = false;
                s_tx_head = s_tx_tail = 0;
                s_tx_waiting = false;
            }
            break;
        }
        default:
            break;
    }
}

/* -------------------------------------------------------------- public */

void aap_connect(bd_addr_t addr)
{
    if (s_open || s_opening) {
        printf("AAP: channel already up/opening (cid 0x%04x)\n", s_cid);
        return;
    }
    memcpy(s_addr, addr, 6);
    printf("AAP: opening L2CAP PSM 0x%04x to %s ...\n", AAP_PSM,
           bd_addr_to_str(addr));
    s_opening = true;
    uint8_t status = l2cap_create_channel(aap_packet_handler, addr, AAP_PSM,
                                          AAP_MTU, &s_cid);
    if (status != ERROR_CODE_SUCCESS) {
        printf("AAP: l2cap_create_channel failed 0x%02x\n", status);
        s_opening = false;
        s_cid = 0;
    }
}

void aap_disconnect(void)
{
    if (s_cid) {
        printf("AAP: closing channel (user disconnect)\n");
        l2cap_disconnect(s_cid);
    }
    s_open = false;
    s_opening = false;
    s_cid = 0;
    s_protocol_seen = false;
}

void aap_set_jitter_raw(uint8_t value)
{
    s_jitter = value;
    if (!s_open) {
        printf("AAP: channel not open - can't set jitter (auto-opens on A2DP connect)\n");
        return;
    }
    aap_send_ctl(CTL_JITTER, value);
    printf("AAP -> Set Jitter Buffer = %u ms\n", value);
}

void aap_cycle_jitter(void)
{
    uint8_t next = s_jitter == 150 ? 60 : s_jitter == 60 ? 30 : 150;
    aap_set_jitter_raw(next);
}

void aap_probe_4c(void)
{
#if !AAP_ALLOW_DEBUG_PROBES
    printf("AAP: 0x4c probe disabled (unverified write)\n");
    return;
#else
    if (!s_open) {
        printf("AAP: no channel — 0x4c probe skipped\n");
        return;
    }
    static const uint8_t p[8] = { 0x04,0x00,0x04,0x00,0x4C,0x00,0x00,0x00 };
    aap_send(p, sizeof(p));
    printf("AAP -> 0x4c status probe (watch [aap<] for the answer)\n");
#endif
}

void aap_send_09_03(uint8_t v)
{
#if !AAP_ALLOW_DEBUG_PROBES
    printf("AAP: 09/03 probe disabled (unverified write)\n");
    return;
#else
    if (!s_open) {
        printf("AAP: no channel — 09/03 skipped\n");
        return;
    }
    aap_send_ctl(0x03, v);
    printf("AAP -> 0x09/0x03 value %u (watch for 0x0e/0x55 beacons)\n", v);
#endif
}

void aap_get_battery(uint8_t out[3])
{
    out[0] = s_battery[0];
    out[1] = s_battery[1];
    out[2] = s_battery[2];
}

bool    aap_channel_open(void)   { return s_open; }
bool    aap_protocol_seen(void)  { return s_protocol_seen; }
uint8_t aap_get_noise_mode(void){ return s_noise_mode; }
bool    aap_get_ear_pause(void)  { return s_ear_pause; }
bool    aap_get_game(void)       { return s_game; }
int     aap_get_pvol(void)       { return s_pvol; }
int     aap_get_ca(void)         { return s_ca; }
int     aap_get_aa(void)         { return s_aa; }

void aap_set_noise_mode(uint8_t mode)
{
    if (!s_open) {
        printf("AAP: channel not opened (open the A2DP link first)\n");
        return;
    }
    s_noise_mode = mode;
    aap_send_ctl(CTL_NOISE, mode);
}

void aap_set_ear_pause(bool on) { s_ear_pause = on; }

void aap_set_game(bool on)
{
    s_game = on;
    if (on) printf("AAP: gaming mode ON\n");
}

void aap_set_pvol(bool on)
{
    s_pvol = on ? 1 : 0;
    aap_send_ctl(CTL_PVOL, on ? 0x01 : 0x02);
}

void aap_set_ca(bool on)
{
    s_ca = on ? 1 : 0;
    aap_send_ctl(CTL_CA, on ? 0x01 : 0x02);
}

void aap_set_aa(uint8_t strength)
{
    s_aa = strength;
    aap_send_ctl(CTL_AA, strength);
}

uint8_t aap_game_jitter(void)
{
    /* game_level: 0/1 = Stable first (90 ms), 2 = Latency first (60 ms) */
    return settings()->game_level == 2 ? 60 : 90;
}

uint32_t aap_last_lock_ms(void) { return s_last_lock_ms; }

bool aap_renderer_live(void) { return s_renderer_live; }
uint32_t aap_last_render_ms(void) { return s_last_render_ms; }
static void open_channel(unsigned cid){uint8_t e[]={L2CAP_EVENT_CHANNEL_OPENED,0,cid};aap_packet_handler(HCI_EVENT_PACKET,0,e,sizeof e);}
int main(void){
 open_channel(0x42);
 uint8_t close_old[]={L2CAP_EVENT_CHANNEL_CLOSED,0,0x41};
 aap_packet_handler(HCI_EVENT_PACKET,0,close_old,sizeof close_old);
 assert(!s_open && s_cid==0);puts("REPRO: stale close clears the new channel");
 open_channel(0x42);
 uint8_t pending=(s_tx_head+8-s_tx_tail)%8;
 test_send_rc=1;uint8_t send[]={L2CAP_EVENT_CAN_SEND_NOW};
 aap_packet_handler(HCI_EVENT_PACKET,0,send,sizeof send);
 assert((s_tx_head+8-s_tx_tail)%8==pending-1);puts("REPRO: failed send discards a provisioning frame");
 uint8_t malformed[]={0xff,0xff,0xff,0xff,9,0,0x0d,2};
 aap_packet_handler(L2CAP_DATA_PACKET,0x42,malformed,sizeof malformed);
 assert(s_protocol_seen && s_noise_mode==2);puts("REPRO: invalid header accepted as confirmed control state");
 uint8_t stale[]={4,0,4,0,9,0,0x0d,4};
 aap_packet_handler(L2CAP_DATA_PACKET,0x41,stale,sizeof stale);
 assert(s_noise_mode==4);puts("REPRO: data on a stale channel changes current state");

 s_ear_pause=true;s_ear_last=0;media_events=0;
 uint8_t one_bud[]={4,0,4,0,6,0,0,1};
 aap_packet_handler(L2CAP_DATA_PACKET,0x42,one_bud,sizeof one_bud);
 assert(s_ear_last==1 && media_events==1);puts("REPRO: one worn bud triggers a play/pause toggle when the other is removed");
 return 0;
}
