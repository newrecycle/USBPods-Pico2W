
#include <stdint.h>
#include <stdbool.h>
#include <stdio.h>
#include <string.h>
#include <assert.h>
#define HCI_EVENT_PACKET 4
#define HCI_EVENT_A2DP_META 0xd1
#define ERROR_CODE_SUCCESS 0
#define A2DP_SUBEVENT_SIGNALING_MEDIA_CODEC_SBC_CONFIGURATION 1
#define A2DP_SUBEVENT_SIGNALING_MEDIA_CODEC_MPEG_AAC_CONFIGURATION 2
#define A2DP_SUBEVENT_STREAM_ESTABLISHED 3
#define A2DP_SUBEVENT_STREAM_STARTED 4
#define A2DP_SUBEVENT_STREAM_SUSPENDED 5
#define A2DP_SUBEVENT_STREAM_STOPPED 6
#define A2DP_SUBEVENT_STREAM_RELEASED 7
#define A2DP_SUBEVENT_SIGNALING_CONNECTION_RELEASED 8
#define BD_ADDR_TYPE_ACL 0
#define RELAY_PKT_N 12
#define AVDTP_SINK_FEATURE_MASK_HEADPHONE 1
typedef struct {int con_handle;} hci_connection_t;
static uint8_t s_codec,s_channels,s_phone_addr[6],s_sdp_buf[160],s_pkt_head,s_pkt_tail,s_pkt[12][1024];
static uint16_t s_rate,s_avdtp_cid,s_con_handle,s_pkt_len[12];
static bool s_connected,s_streaming,s_stream_reset_pending,s_phone_stream_started,s_need_resample,s_sdp_registered=true;
static uint32_t s_connect_ms,s_first_pkt_ms,s_pkts,s_in_bytes,s_dec_us_last,s_dec_us_sum,s_dec_n,s_dec_us_max;
static int s_sbc_dec;
static uint32_t now_ms(void){return 10;}
static uint32_t time_us_32(void){return 10;}
static int hci_event_packet_get_type(uint8_t *p){return p[0];}
static int a2dp_subevent_signaling_media_codec_sbc_configuration_get_num_channels(uint8_t*p){return 2;}
static int a2dp_subevent_signaling_media_codec_sbc_configuration_get_sampling_frequency(uint8_t*p){return 48000;}
static int a2dp_subevent_signaling_media_codec_mpeg_aac_configuration_get_sampling_frequency(uint8_t*p){return 48000;}
static int a2dp_subevent_signaling_media_codec_mpeg_aac_configuration_get_num_channels(uint8_t*p){return 2;}
static int a2dp_subevent_stream_established_get_status(uint8_t*p){return 0;}
static void a2dp_subevent_stream_established_get_bd_addr(uint8_t*p,uint8_t*a){memset(a,1,6);}
static int a2dp_subevent_stream_established_get_a2dp_cid(uint8_t*p){return p[3];}
static hci_connection_t *hci_connection_for_bd_addr_and_type(uint8_t*a,int t){return NULL;}
static void settings_phone_add(uint8_t*a,char*s){}
static char *bd_addr_to_str(uint8_t*a){return "peer";}
int get_current_sample_rate(void){return 48000;}
static void pcm_reset(void){}
static void aac_close(void){}
static void aac_decode(const uint8_t*p,uint16_t n){}
static void btstack_sbc_decoder_process_data(int*s,int mode,const uint8_t*p,uint16_t n){}
static int sdp_create_service_record_handle(void){return 1;}
static void a2dp_sink_create_sdp_record(uint8_t*b,int h,int f,char*s,char*t){}
static int sdp_register_service(uint8_t*b){return 0;}
static void rtp_strip(const uint8_t *in, uint16_t n, const uint8_t **out, uint16_t *out_n)
{
    if (n < 12) { *out = NULL; return; }
    uint8_t cc = in[0] & 0x0F;
    uint16_t off = (uint16_t)(12 + cc * 4);
    if (in[0] & 0x10) {                 /* extension header */
        if (off + 4 > n) { *out = NULL; return; }
        uint16_t ext = (uint16_t)((in[off + 2] << 8) | in[off + 3]);
        off = (uint16_t)(off + 4 + ext * 4);
    }
    if (off >= n) { *out = NULL; return; }
    if (in[0] & 0x20) {                 /* padding */
        uint8_t pad = in[n - 1];
        if (pad >= n - off) { *out = NULL; return; }
        n = (uint16_t)(n - pad);
    }
    *out = in + off;
    *out_n = (uint16_t)(n - off);
}static void packet_handler(uint8_t packet_type, uint16_t channel, uint8_t *packet, uint16_t size)
{
    (void)channel; (void)size;
    if (packet_type != HCI_EVENT_PACKET) return;
    if (hci_event_packet_get_type(packet) != HCI_EVENT_A2DP_META) return;

    switch (packet[2]) {
        case A2DP_SUBEVENT_SIGNALING_MEDIA_CODEC_SBC_CONFIGURATION: {
            uint8_t nch = a2dp_subevent_signaling_media_codec_sbc_configuration_get_num_channels(packet);
            uint32_t rate = a2dp_subevent_signaling_media_codec_sbc_configuration_get_sampling_frequency(packet);
            s_codec = 1;
            s_rate = (uint16_t)rate;
            s_channels = nch;
            printf("[relay] phone SBC config: %lu Hz, %u ch%s\n",
                   (unsigned long)rate, nch,
                   rate == 48000 ? "" : " (resampling to 48k)");
            /* The AVDTP acceptor has already accepted this configuration and
             * moved state; a2dp_sink_set_config_sbc() would return
             * COMMAND_DISALLOWED here.  The event fields are all we need. */
            break;
        }
        case A2DP_SUBEVENT_SIGNALING_MEDIA_CODEC_MPEG_AAC_CONFIGURATION: {
            uint32_t rate = a2dp_subevent_signaling_media_codec_mpeg_aac_configuration_get_sampling_frequency(packet);
            uint8_t  nch  = a2dp_subevent_signaling_media_codec_mpeg_aac_configuration_get_num_channels(packet);
            s_codec = 2;
            s_rate = (uint16_t)rate;
            s_channels = nch;
            printf("[relay] phone AAC-LC config: %lu Hz, %u ch%s\n",
                   (unsigned long)rate, nch,
                   rate == 48000 ? "" : " (resampling to 48k)");
            break;
        }
        case A2DP_SUBEVENT_STREAM_ESTABLISHED: {
            uint8_t status = a2dp_subevent_stream_established_get_status(packet);
            if (status != ERROR_CODE_SUCCESS) {
                printf("[relay] stream establishment FAILED status 0x%02x\n", status);
                break;
            }
            a2dp_subevent_stream_established_get_bd_addr(packet, s_phone_addr);
            s_avdtp_cid = a2dp_subevent_stream_established_get_a2dp_cid(packet);
            s_connected = true;
            s_connect_ms = now_ms();
            s_con_handle = 0;
            {
                hci_connection_t *c = hci_connection_for_bd_addr_and_type(s_phone_addr, BD_ADDR_TYPE_ACL);
                if (c) s_con_handle = c->con_handle;
            }
            settings_phone_add(s_phone_addr, "");
            printf("[relay] phone connected: %s (avdtp_cid 0x%02x)\n",
                   bd_addr_to_str(s_phone_addr), s_avdtp_cid);
            break;
        }
        case A2DP_SUBEVENT_STREAM_STARTED:
            s_streaming = false;
            s_stream_reset_pending = true;
            s_phone_stream_started = true;
            s_first_pkt_ms = 0;
            {
                extern int get_current_sample_rate(void);
                int pipe = get_current_sample_rate();
                s_need_resample = (s_rate == 44100 && pipe != 44100);
            }
            printf("[relay] phone stream STARTED\n");
            break;
        case A2DP_SUBEVENT_STREAM_SUSPENDED:
        case A2DP_SUBEVENT_STREAM_STOPPED:
            s_streaming = false;
            s_need_resample = false;
            printf("[relay] phone stream stopped (%s)\n",
                   packet[2] == A2DP_SUBEVENT_STREAM_STOPPED ? "stopped" : "suspended");
            break;
        case A2DP_SUBEVENT_STREAM_RELEASED:
            s_streaming = false;
            s_connected = false;
            s_avdtp_cid = 0;
            s_con_handle = 0;
            printf("[relay] phone media channel released\n");
            break;
        case A2DP_SUBEVENT_SIGNALING_CONNECTION_RELEASED:
            s_streaming = false;
            s_connected = false;
            s_avdtp_cid = 0;
            s_con_handle = 0;
            printf("[relay] phone disconnected\n");
            break;
        default:
            break;
    }
}bool bt_sink_relay_work(void)
{
    if (!s_sdp_registered) {
        /* bt_sink_relay_init() runs before sdp_init() in btstack_main, so the
         * SDP record must be registered here, from the main loop, once the
         * service database exists. */
        memset(s_sdp_buf, 0, sizeof(s_sdp_buf));
        a2dp_sink_create_sdp_record(s_sdp_buf, sdp_create_service_record_handle(),
                                    AVDTP_SINK_FEATURE_MASK_HEADPHONE,
                                    "USBPods Relay", "USBPods");
        if (sdp_register_service(s_sdp_buf) == ERROR_CODE_SUCCESS) {
            s_sdp_registered = true;
        } else {
            printf("[relay] SDP register FAILED\n");
            s_sdp_registered = true;   /* do not retry every main-loop tick */
        }
    }
    if (s_stream_reset_pending) {
        s_stream_reset_pending = false;
        pcm_reset();
        {
            extern int get_current_sample_rate(void);
            int pipe = get_current_sample_rate();
            s_need_resample = (s_rate == 44100 && pipe != 44100);
        }
        if (s_codec == 2) aac_close();
        s_streaming = true;
    }
    if (s_pkt_tail == s_pkt_head) return false;
    uint8_t slot = s_pkt_tail;
    uint16_t len = s_pkt_len[slot];
    s_pkt_tail = (uint8_t)((s_pkt_tail + 1) % RELAY_PKT_N);
    if (!s_streaming) return true;

    uint32_t t0 = time_us_32();
    const uint8_t *payload;
    uint16_t plen;
    rtp_strip(s_pkt[slot], len, &payload, &plen);
    if (!payload || plen == 0) return true;

    s_pkts++;
    s_in_bytes += plen;
    if (!s_first_pkt_ms) s_first_pkt_ms = now_ms();

    if (s_codec == 1) {
        if (plen < 2) return true;
        uint8_t nframes = payload[0];
        const uint8_t *sbc = payload + 1;
        uint16_t slen = (uint16_t)(plen - 1);
        (void)nframes;
        btstack_sbc_decoder_process_data(&s_sbc_dec, 0, sbc, slen);
    } else if (s_codec == 2) {
        aac_decode(payload, plen);
    }

    uint32_t dt = time_us_32() - t0;
    s_dec_us_last = dt;
    s_dec_us_sum += dt;
    s_dec_n++;
    if (dt > s_dec_us_max) s_dec_us_max = dt;
    return true;
}
static void event(uint8_t type,uint8_t cid){uint8_t p[]={HCI_EVENT_A2DP_META,0,type,cid};packet_handler(HCI_EVENT_PACKET,0,p,sizeof p);}
int main(void){
 s_connected=true;s_avdtp_cid=0x42;
 event(A2DP_SUBEVENT_STREAM_STARTED,0x42);
 event(A2DP_SUBEVENT_STREAM_SUSPENDED,0x42);
 assert(!s_streaming);bt_sink_relay_work();
 assert(s_streaming);puts("REPRO: START then SUSPEND before main work resumes the stopped stream");
 s_stream_reset_pending=false;s_connected=true;s_avdtp_cid=0x42;
 event(A2DP_SUBEVENT_SIGNALING_CONNECTION_RELEASED,0x41);
 assert(!s_connected && s_avdtp_cid==0);puts("REPRO: another connection's release clears the phone session");
 uint8_t rtp[20]={0x90,0};rtp[14]=0x40;rtp[15]=0;const uint8_t*out=NULL;uint16_t n=0;
 rtp_strip(rtp,sizeof rtp,&out,&n);
 assert(out==rtp+16 && n==4);puts("REPRO: RTP extension size wraps at 65536 and malformed packet is accepted");
 return 0;
}
